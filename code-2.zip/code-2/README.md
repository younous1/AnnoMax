Repertoire qui regroupe **tous les fichiers** de la version **minimale** du projet
